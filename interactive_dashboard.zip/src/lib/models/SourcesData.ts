export interface SourcesData {
  sources: string [];
}
