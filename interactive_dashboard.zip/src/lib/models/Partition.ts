export interface Partition {
  id: string;
  brand: string;
  country: string;
}
