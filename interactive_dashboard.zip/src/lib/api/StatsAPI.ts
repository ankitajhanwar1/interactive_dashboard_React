import {
  ConversionsStats,
  RevenueStats,
  SpendStats,
  SummaryStats,
} from "../models/Stats";
import { api, buildQueryString } from "./AxiosInstance";
import { Endpoints } from "./Endpoint";

export const fetchSummaryStatistics = async (
  partitionId: string,
  queryParams?: Record<string, string | undefined>
): Promise<SummaryStats> => {
  const queryStringParams = buildQueryString(queryParams);
  const queryString = queryStringParams ? `?${queryStringParams}` : "";
  const response = await api.get<SummaryStats>(
    `${Endpoints.summaryStats.replace(
      ":partitionId",
      `${partitionId}`
    )}${queryString}`
  );
  return response.data;
};

export const fetchRevenueStatistics = async (
  partitionId: string
): Promise<RevenueStats> => {
  const response = await api.get<RevenueStats>(
    Endpoints.revenue.replace(":partitionId", `${partitionId}`)
  );
  return response.data;
};

export const fetchConversionsStatistics = async (
  partitionId: string
): Promise<ConversionsStats> => {
  const response = await api.get<ConversionsStats>(
    Endpoints.conversions.replace(":partitionId", `${partitionId}`)
  );
  return response.data;
};

export const fetchSpendStatistics = async (
  partitionId: string
): Promise<SpendStats> => {
  const response = await api.get<SpendStats>(
    Endpoints.spend.replace(":partitionId", `${partitionId}`)
  );
  return response.data;
};
