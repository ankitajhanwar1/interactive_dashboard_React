import axios from "axios";
import { BASE_URL } from "../../constants";

export const api = axios.create({
  baseURL: BASE_URL,
  headers: {
    "x-api-key": "woope1Pei5zieg", //This value can be taken for env for security reasons when we deploy the code
  },
});

export const buildQueryString = ( params: Record<string, string | number | undefined> |undefined): string => {
  const queryString = new URLSearchParams();
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null) {
        queryString.append(key, value.toString());
      }
    });
  }
  return queryString.toString();
};
